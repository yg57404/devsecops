sh """
/usr/local/bin/trufflehog filesystem --only-verified --no-update $workspace/ > truffle.txt
if [ `cat truffle.txt | grep verified |wc -l` -gt 0 ]; then
cat truffle.txt
truncate -s 0 truffle.txt
echo "Found Keys in code. Deployment will not proceed" ; exit 1 ;
else
cat truffle.txt
echo "No Keys found in code"
truncate -s 0 truffle.txt
fi
"""